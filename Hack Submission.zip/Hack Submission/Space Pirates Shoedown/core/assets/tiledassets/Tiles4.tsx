<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Tiles4" tilewidth="32" tileheight="32" tilecount="108" columns="9">
 <image source="submission_daneeklu/tilesets/plants.png" width="288" height="384"/>
 <tile id="40">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
