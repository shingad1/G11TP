<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="singleEnemyTileset" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="singleEnemy.png" width="32" height="32"/>
 <tile id="0">
  <properties>
   <property name="basicEnemy" value="true"/>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
