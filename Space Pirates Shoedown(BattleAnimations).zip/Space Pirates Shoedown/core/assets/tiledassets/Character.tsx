<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Character" tilewidth="32" tileheight="32" tilecount="12" columns="3">
 <image source="MainGuySpriteSheet.png" width="124" height="144"/>
</tileset>
