<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Fishing" tilewidth="32" tileheight="32" tilecount="400" columns="20">
 <image source="submission_daneeklu/tilesets/farming_fishing.png" width="640" height="640"/>
</tileset>
