<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="InteriorTiles" tilewidth="32" tileheight="32" tilecount="504" columns="24">
 <image source="ak&amp;#039;s_assets.png" width="768" height="672"/>
 <tile id="227">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="228">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="229">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="233">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="235">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="236">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="237">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="238">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="239">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="251">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="252">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="253">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="254">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="255">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="256">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="257">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="258">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="259">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="260">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="261">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="262">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="263">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="275">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="276">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="277">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="278">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="279">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="280">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="281">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="282">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="283">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="284">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="285">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="286">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="287">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="299">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="300">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="301">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="302">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="303">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="304">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="305">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="306">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="307">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="308">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="309">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="310">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="311">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="323">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="324">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="325">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="326">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="327">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="328">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="329">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="330">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="331">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="332">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="333">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="334">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="347">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="348">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="349">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="350">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="351">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="352">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="353">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="354">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="355">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="356">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="357">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="358">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="359">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
