<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="pinktree" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="144" columns="12">
 <image source="../../CandyLand/plant repack.png" width="416" height="416"/>
 <tile id="5">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
