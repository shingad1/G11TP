<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Terrain" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="terrain.png" width="1024" height="1024"/>
 <tile id="385">
  <properties>
   <property name="leave" value="true"/>
  </properties>
 </tile>
</tileset>
