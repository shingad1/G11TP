<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="lpcforest2" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="225" columns="15">
 <image source="../../../../Hack Submission/Space Pirates Shoedown/core/assets/tiledassets/img/LPC_forest/LPC_forest/forest_tiles2.png" width="512" height="512"/>
</tileset>
