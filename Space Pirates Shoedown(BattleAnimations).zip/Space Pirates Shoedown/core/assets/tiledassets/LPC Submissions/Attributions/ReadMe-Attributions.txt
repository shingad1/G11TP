These are the attirubtions/instructions for attributions from all the resources in this LPC set. Some may be duplicates...

Adobe:
Please link to the OpenGameArt.org page where this came from (if reasonable), attribute Sharm as graphic artist, and William Thompson as contributor (since he did pay out of the goodness of my heart to have this set made after all...)

http://opengameart.org/content/lpc-adobe-building-set

Arabic:

Please link to the OpenGameArt.org page where this came from (if reasonable), attribute Sharm as graphic artist, and William Thompson as contributor (since he did pay out of the goodness of my heart to have this set made after all...)

http://opengameart.org/content/lpc-arabic-elements


Exterior/Interior(1&2)/Outside Objects/Terrain and Outside: 

See: 
Attribution/Attribution 2 (copied and pasted into the folder "attributions" from set "base_out_atas and terrain_atlas" and "build_atlas and obj_misk_atlas")

See:
Items&Effects (pased from Items and Efffects)

See: Terrain2 Attribution

See: Credits as copied and pasted portions from smaller sets...







