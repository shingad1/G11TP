<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="CandyLandTiles2" tilewidth="32" tileheight="32" tilecount="160" columns="8">
 <image source="CandyLand2.png" width="256" height="640"/>
</tileset>
