<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="CandyLandTiles2" tilewidth="32" tileheight="32" tilecount="160" columns="8">
 <image source="CandyLand/CandyLand2.png" width="256" height="640"/>
 <tile id="0">
  <properties>
   <property name="invisible" value="true"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="104">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="105">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="111">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="112">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="118">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="119">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="120">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="121">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="123">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="128">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="131">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="132">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="133">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="134">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="135">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="136">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="137">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="138">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="139">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="144">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
