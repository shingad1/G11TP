<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="bluehouse" tilewidth="32" tileheight="32" tilecount="450" columns="25">
 <image source="../../../../Hack Submission/Space Pirates Shoedown/core/assets/tiledassets/img/1/bluehouse.png" width="800" height="600"/>
</tileset>
