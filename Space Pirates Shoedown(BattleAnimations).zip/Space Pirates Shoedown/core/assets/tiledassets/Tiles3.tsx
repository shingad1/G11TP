<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Tiles3" tilewidth="32" tileheight="32" tilecount="400" columns="20">
 <image source="submission_daneeklu/tilesets/farming_fishing.png" width="640" height="640"/>
 <tile id="5">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="87">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="103">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="104">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="106">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="107">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="123">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="143">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="144">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="208">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="209">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="210">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="211">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="212">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="213">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="214">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="221">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="228">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="229">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="233">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="236">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="261">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="291">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="292">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="293">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="294">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="301">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="311">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="312">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="313">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="314">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="355">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
 <tile id="356">
  <properties>
   <property name="blocked" value="true"/>
  </properties>
 </tile>
</tileset>
