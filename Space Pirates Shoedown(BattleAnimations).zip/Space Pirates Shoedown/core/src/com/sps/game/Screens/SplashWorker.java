package com.sps.game.Screens;

public interface SplashWorker {

    public void closeSplashScreen();
}
